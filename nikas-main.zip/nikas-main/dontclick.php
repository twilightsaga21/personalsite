<?php
header("Location: https://www.youtube.com/watch?v=dQw4w9WgXcQ");
exit();
?>
